# 商品授权条款 / Product License

> 放在每个商品页底部，并在 ZIP 里附一份 LICENSE.txt。

---

## 买家可以（Permitted）

1. 用于个人项目：社交头像、个人网站、作品集、印刷品
2. 用于商业项目：广告素材、电商详情页、品牌官网、短视频、封面图
3. 修改：裁剪、调色、合成、加字
4. 在社交媒体和付费广告中使用
5. 用于**最多 3 个**商业项目（超出请购买多份授权）

## 买家不可以（Prohibited）

1. 转售、再分发、打包出售原始图片或修改后的图片（作为图库、素材包、模板）
2. 上传到其他图库、素材站、AI 训练数据集
3. 用于成人内容、色情、陪侍服务
4. 用于诽谤、侮辱、政治宣传，或损害模特名誉的用途
5. 声称照片中的人是自己的产品或服务的真实用户（虚假代言）
6. 把照片用于商标注册、NFT 铸造

## 说明

- 本商品为数字文件，**售出后不支持退款**；文件损坏可免费补发
- 照片中的模特已签署肖像授权，授权范围覆盖本商品的正常使用
- 若照片为 AI 生成，会在商品页明确标注，且不含真人肖像
- 授权不可转让，仅限购买者本人或其所属公司使用

---

## English

**You may:** use the images in personal and commercial projects (social media, ads, websites, e-commerce, print, video), crop, color grade and composite them, across paid and organic channels, in up to 3 commercial projects per purchase.

**You may not:** resell, redistribute or repackage the images (raw or modified) as stock, templates or asset packs; upload them to stock libraries or AI training datasets; use them in adult, escort, defamatory, political or reputational-harm contexts; imply that the person endorses your product; register them as trademarks; mint them as NFTs.

**Notes:** digital goods are non-refundable after download; damaged files are replaced free of charge. Model releases cover normal use of this product. AI-generated images are labeled on the product page. The license is non-transferable.
